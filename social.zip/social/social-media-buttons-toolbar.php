<?php
/**
 * Plugin Name: Custom Social
 * Plugin URI: https://github.com/AmrahImtiaz/HackByte
 * Description: #
 * Author: Amrah Imtiaz
 * Author URI: https://github.com/AmrahImtiaz/HackByte
 * Version: 5.0
 * License: GPL3 * Prevent Direct Access
 */
defined( 'ABSPATH' ) or die( "Restricted access!" );

/**
 * Define global constants
 */
$plugin_data = get_file_data( __FILE__,
                              array(
                                     'name'    => 'Plugin Name',
                                     'version' => 'Version',
                                     'text'    => 'Text Domain'
                                   )
                            );
function spacexchimp_p005_define_constants( $constant_name, $value ) {
    $constant_name = 'SPACEXCHIMP_P005_' . $constant_name;
    if ( ! defined( $constant_name ) )
        define( $constant_name, $value );
}
spacexchimp_p005_define_constants( 'FILE', __FILE__ );
spacexchimp_p005_define_constants( 'DIR', dirname( plugin_basename( __FILE__ ) ) );
spacexchimp_p005_define_constants( 'BASE', plugin_basename( __FILE__ ) );
spacexchimp_p005_define_constants( 'URL', plugin_dir_url( __FILE__ ) );
spacexchimp_p005_define_constants( 'PATH', plugin_dir_path( __FILE__ ) );
spacexchimp_p005_define_constants( 'SLUG', dirname( plugin_basename( __FILE__ ) ) );
spacexchimp_p005_define_constants( 'NAME', $plugin_data['name'] );
spacexchimp_p005_define_constants( 'VERSION', $plugin_data['version'] );
spacexchimp_p005_define_constants( 'TEXT', $plugin_data['text'] );
spacexchimp_p005_define_constants( 'PREFIX', 'spacexchimp_p005' );
spacexchimp_p005_define_constants( 'SETTINGS', 'spacexchimp_p005' );

/**
 * A useful function that returns an array with the contents of the plugin constants
 */
function spacexchimp_p005_plugin() {
    $array = array(
        'file'     => SPACEXCHIMP_P005_FILE,
        'dir'      => SPACEXCHIMP_P005_DIR,
        'base'     => SPACEXCHIMP_P005_BASE,
        'url'      => SPACEXCHIMP_P005_URL,
        'path'     => SPACEXCHIMP_P005_PATH,
        'slug'     => SPACEXCHIMP_P005_SLUG,
        'name'     => SPACEXCHIMP_P005_NAME,
        'version'  => SPACEXCHIMP_P005_VERSION,
        'text'     => SPACEXCHIMP_P005_TEXT,
        'prefix'   => SPACEXCHIMP_P005_PREFIX,
        'settings' => SPACEXCHIMP_P005_SETTINGS
    );
    return $array;
}

/**
 * Put value of plugin constants into an array for easier access
 */
$plugin = spacexchimp_p005_plugin();

/**
 * Load the plugin modules
 */
require_once( $plugin['path'] . 'inc/php/core.php' );
require_once( $plugin['path'] . 'inc/php/items.php' );
require_once( $plugin['path'] . 'inc/php/items-handler.php' );
require_once( $plugin['path'] . 'inc/php/options.php' );
require_once( $plugin['path'] . 'inc/php/upgrade.php' );
require_once( $plugin['path'] . 'inc/php/versioning.php' );
require_once( $plugin['path'] . 'inc/php/enqueue.php' );
require_once( $plugin['path'] . 'inc/php/functional.php' );
require_once( $plugin['path'] . 'inc/php/controls.php' );
require_once( $plugin['path'] . 'inc/php/page.php' );
require_once( $plugin['path'] . 'inc/php/messages.php' );
